package ca.lensAssign.ui;

import ca.lensAssign.model.DepthOfFieldCalculator;
import ca.lensAssign.model.Lens;
import ca.lensAssign.model.LensManager;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 *
 *
 */
public class CameraTextUI {
    private static final double COC = 0.029;    // "Circle of Confusion" for a "Full Frame" camera
    private LensManager manager;
    private Scanner in = new Scanner(System.in);// Read from keyboard


    public CameraTextUI(LensManager manager) {
        // Accept and store a reference to the lens manager (the model)
        // (this design is called "dependency injection")
        this.manager = manager;

        // Populate lenses (Make, max aperture (smallest supported F number), focal length [mm]):
        manager.add(new Lens("Canon", 1.8, 50));
        manager.add(new Lens("Tamron", 2.8, 90));
        manager.add(new Lens("Sigma", 2.8, 200));
        manager.add(new Lens("Nikon", 4, 200));
    }

    public void show() {

        boolean isDone = false;
        while(!isDone){
            System.out.println("Lenses to pick from:");
            System.out.println("  0. Canon 50mm F1.8");
            System.out.println("  1. Tamron 90mm F2.8");
            System.out.println("  2. Sigma 200mm F2.8");
            System.out.println("  3. Nikon 200mm F4.0");
            System.out.println("  (-1 to exit)");
            System.out.println(": ");


            //Scanner in = new Scanner(System.in);
            int choice = in.nextInt();

            switch(choice) {
                case 0:
                    System.out.println("Aperture [the F number]: ");

                    double FNum = in.nextDouble();
                    if(FNum < 1.8){
                        System.out.println("ERROR: This aperture is not possible with this lens\n");
                    }
                    else{
                        System.out.println("Distance to subject [m]: ");
                        double DisToSub = in.nextDouble();
                        DepthOfFieldCalculator canon = new DepthOfFieldCalculator(50,1.8,FNum,DisToSub,COC);

                        System.out.println("  In focus: " + formatM(canon.getNearFocalPoint())
                                + "m to " + formatM(canon.getFarFocalPoint())
                                + "m [DoF = " + formatM(canon.getDepthOfField()) + "m]");

                        System.out.println("  Hyperfocal point: " + formatM(canon.getHyperFocalDistance()) + "m");
                    }
                    break;
                case 1:
                    System.out.println("Aperture [the F number]: ");

                    FNum = in.nextDouble();
                    if(FNum < 2.8){
                        System.out.println("ERROR: This aperture is not possible with this lens\n");
                    }
                    else{
                        System.out.println("Distance to subject [m]: ");
                        double DisToSub = in.nextDouble();
                        DepthOfFieldCalculator tamron = new DepthOfFieldCalculator(90,2.8,FNum,DisToSub,COC);

                        System.out.println("  In focus: " + formatM(tamron.getNearFocalPoint())
                                + "m to " + formatM(tamron.getFarFocalPoint())
                                + "m [DoF = " + formatM(tamron.getDepthOfField()) + "m]");

                        System.out.println("  Hyperfocal point: " + formatM(tamron.getHyperFocalDistance()) + "m");
                    }
                    break;
                case 2:
                    System.out.println("Aperture [the F number]: ");

                    FNum = in.nextDouble();
                    if(FNum < 2.8){
                        System.out.println("ERROR: This aperture is not possible with this lens\n");
                    }
                    else{
                        System.out.println("Distance to subject [m]: ");
                        double DisToSub = in.nextDouble();
                        DepthOfFieldCalculator nikon = new DepthOfFieldCalculator(200,2.8,FNum,DisToSub,COC);

                        System.out.println("  In focus: " + formatM(nikon.getNearFocalPoint()
                                + "m to " + formatM(nikon.getFarFocalPoint())
                                + "m [DoF = " + formatM(nikon.getDepthOfField()) + "m]");

                        System.out.println("  Hyperfocal point: " + formatM(nikon.getHyperFocalDistance()) + "m");
                    }
                    break;
                case 3:
                    System.out.println("Aperture [the F number]: \t3");

                    FNum = in.nextDouble();
                    if(FNum < 4.0){
                        System.out.println("ERROR: This aperture is not possible with this lens\n");
                    }
                    else{
                        System.out.println("Distance to subject [m]: ");
                        double DisToSub = in.nextDouble();
                        DepthOfFieldCalculator sigma = new DepthOfFieldCalculator(200,4.0,FNum,DisToSub,COC);

                        System.out.println("  In focus: " + formatM(sigma.getNearFocalPoint())
                                + "m to " + formatM(sigma.getFarFocalPoint())
                                + "m [DoF = " + formatM(sigma.getDepthOfField()) + "m]");

                        System.out.println("  Hyperfocal point: " + formatM(sigma.getHyperFocalDistance()) + "m");
                    }
                    break;
                case -1:
                    isDone = true;
                    break;
                default:
                    System.out.println("ERROR: Invalid lens index.");
                    break;

            }
        }
    }

    private String formatM(double distanceInM) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(distanceInM);
    }
}