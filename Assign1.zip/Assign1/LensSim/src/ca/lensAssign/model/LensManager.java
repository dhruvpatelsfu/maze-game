package ca.lensAssign.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LensManager implements Iterable<Lens> {
    private List<Lens> lensList = new ArrayList<>();

    public void add(Lens lens) {
        lensList.add(lens);
    }

    public Lens get(int index) {
        return lensList.get(index);
    }

    @Override
    public Iterator<Lens> iterator() {
        return lensList.iterator();
    }
}
