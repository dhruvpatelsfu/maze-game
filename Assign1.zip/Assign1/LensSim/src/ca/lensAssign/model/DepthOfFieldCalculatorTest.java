package ca.lensAssign.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DepthOfFieldCalculatorTest {

    @Test
    void getHyperFocalDistance() {
        DepthOfFieldCalculator lens1 = new DepthOfFieldCalculator(50,1.8,1.8,1.1,0.029);
        assertEquals(47.89,lens1.getHyperFocalDistance(),0.01);

        DepthOfFieldCalculator lens2 = new DepthOfFieldCalculator(90,2.8,4.0,30,0.029);
        assertEquals(69.83,lens2.getHyperFocalDistance(),0.01);
    }

    @Test
    void getNearFocalDistance() {
        DepthOfFieldCalculator lens1 = new DepthOfFieldCalculator(50,1.8,1.8,1.1,0.029);
        assertEquals(1.08,lens1.getNearFocalPoint(),0.01);
    }

    @Test
    void getFarFocalDistance() {
        DepthOfFieldCalculator lens1 = new DepthOfFieldCalculator(50,1.8,1.8,1.1,0.029);
        assertEquals(1.12,lens1.getFarFocalPoint(),0.01);

        DepthOfFieldCalculator lens2 = new DepthOfFieldCalculator(50,1.8,11,15,0.029);
        assertEquals(Double.POSITIVE_INFINITY,lens2.getFarFocalPoint());
    }

    @Test
    void getDepthOfField() {
        DepthOfFieldCalculator lens1 = new DepthOfFieldCalculator(50,1.8,1.8,1.1,0.029);
        assertEquals(0.05,lens1.getDepthOfField(),0.01);

        DepthOfFieldCalculator lens2 = new DepthOfFieldCalculator(50,1.8,11,15,0.029);
        assertEquals(Double.POSITIVE_INFINITY,lens2.getDepthOfField());
    }




}