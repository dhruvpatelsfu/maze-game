package ca.lensAssign.model;

public class DepthOfFieldCalculator {
    private double focalLength;
    private double maxApe;
    private double selectedAperture;
    private double distanceToSub;
    private double COC;

    private double hyperFocalDistance;
    private double NearFocalPoint;
    private double FarFocalPoint;
    private double DepthOfField;

    public DepthOfFieldCalculator(double focalLength,double maxApe, double selectedAperture, double distanceToSub, double COC) {
        this.focalLength = focalLength;
        this.maxApe = maxApe;
        this.selectedAperture = selectedAperture;
        this.distanceToSub = distanceToSub * 1000; //convert from meters to mm
        this.COC = COC;
    }

    private void calcHyperFocalDistance(){
        double fLenSqr = this.focalLength * this.focalLength;
        double x = this.selectedAperture * this.COC;
        this.hyperFocalDistance = fLenSqr/x;
    }

    private void calcNearFocalPoint() {
        calcHyperFocalDistance();
        double x = this.hyperFocalDistance * distanceToSub;
        double y = this.hyperFocalDistance + (this.distanceToSub - this.focalLength);
        this.NearFocalPoint = x / y;
    }

    private void calcFarFocalpoint() {
        calcHyperFocalDistance();
        if(this.distanceToSub > this.hyperFocalDistance) {
            this.FarFocalPoint = Double.POSITIVE_INFINITY;
        }
        else {
            double x = this.hyperFocalDistance * this.distanceToSub;
            double y = this.hyperFocalDistance - (this.distanceToSub - this.focalLength);
            this.FarFocalPoint = x / y;
        }

    }

    private void calcDepthOfField() {
        calcNearFocalPoint();
        calcFarFocalpoint();
        if(this.FarFocalPoint == Double.POSITIVE_INFINITY){
            this.DepthOfField = Double.POSITIVE_INFINITY;
        }
        else {
            this.DepthOfField = this.FarFocalPoint - this.NearFocalPoint;
        }
    }

    public double getHyperFocalDistance() {
        calcHyperFocalDistance();
        return this.hyperFocalDistance/1000;
    }

    public double getNearFocalPoint() {
        calcNearFocalPoint();
        return this.NearFocalPoint/1000;
    }

    public double getFarFocalPoint() {
        calcFarFocalpoint();
        return this.FarFocalPoint/1000;
    }

    public double getDepthOfField() {
        calcDepthOfField();
        return this.DepthOfField/1000;
    }
}
