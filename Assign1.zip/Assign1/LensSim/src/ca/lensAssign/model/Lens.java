package ca.lensAssign.model;

public class Lens {
    private String make;
    private double maxApt;
    private int focalLength;

    public Lens(String make, double maxApt, int focalLength) {
        this.make = make;
        this.maxApt = maxApt;
        this.focalLength = focalLength;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public double getMaxApt() {
        return maxApt;
    }

    public void setMaxApt(double maxApt) {
        this.maxApt = maxApt;
    }

    public int getFocalLength() {
        return focalLength;
    }

    public void setFocalLength(int focalLength) {
        this.focalLength = focalLength;
    }

    @Override
    public String toString() {
        return "Lens{" +
                "make='" + make + '\'' +
                ", maxApt=" + maxApt +
                ", focalLength=" + focalLength +
                '}';
    }
}

