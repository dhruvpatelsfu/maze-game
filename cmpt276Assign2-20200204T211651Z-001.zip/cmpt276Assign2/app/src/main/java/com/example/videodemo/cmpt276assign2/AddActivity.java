package com.example.videodemo.cmpt276assign2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

public class AddActivity extends AppCompatActivity {


    public static Intent makeIntentForNewLens(Context c) {
        Intent intent = new Intent(c,AddActivity.class);
        return intent;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
    }
}
