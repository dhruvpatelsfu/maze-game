package com.example.videodemo.cmpt276assign2;

import android.content.Intent;
import android.os.Bundle;

import com.example.videodemo.cmpt276assign2.model.Lens;
import com.example.videodemo.cmpt276assign2.model.LensManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.Collections;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        populateListView();

        setupAddFAB();

    }



    private void populateListView() {

        LensManager manager = LensManager.getInstance();

        manager.add(new Lens("Canon", 50, 1.8));
        manager.add(new Lens("Tamron", 90, 2.8));
        manager.add(new Lens("Sigma", 200, 2.8));
        manager.add(new Lens("Nikon", 200, 4));

        String[] lens = {manager.get(0).toString(), manager.get(1).toString(), manager.get(2).toString(),manager.get(3).toString()};

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(MainActivity.this,R.layout.lenslist, lens);

        ListView list = (ListView) findViewById(R.id.LensListmain);
        list.setAdapter(adapter);
    }

    private void setupAddFAB() {

        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(view -> {
            Intent i = AddActivity.makeIntentForNewLens(MainActivity.this);
            startActivity(i);
        });
    }


}

