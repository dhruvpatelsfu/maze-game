package com.example.videodemo.cmpt276assign2.model;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class LensManager implements Iterable<Lens> {

    private List<Lens> lensList;

    public void add(Lens lens) {
        lensList.add(lens);
    }

    private LensManager() {lensList  = new ArrayList<>();}

    private static LensManager instance;

    public static LensManager getInstance() {
        if(instance == null) {
            instance = new LensManager();
        }
        return instance;
    }

    public Lens get(int index) {
        return lensList.get(index);
    }

    @Override
    public Iterator<Lens> iterator() {
        return lensList.iterator();
    }
}