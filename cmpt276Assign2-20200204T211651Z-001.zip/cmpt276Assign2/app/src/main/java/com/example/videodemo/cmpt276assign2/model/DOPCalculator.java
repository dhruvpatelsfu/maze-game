package com.example.videodemo.cmpt276assign2.model;

public class DOPCalculator {


}
