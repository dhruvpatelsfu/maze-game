package com.example.videodemo.cmpt276assign2.model;

public class Lens {
    private String make;
    private int focalLength;
    private double maxApt;

    public Lens(String make, int focalLength, double maxApt) {
        this.make = make;
        this.focalLength = focalLength;
        this.maxApt = maxApt;
    }

    public String getMake() {
        return make;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public double getMaxApt() {
        return maxApt;
    }

    public void setMaxApt(double maxApt) {
        this.maxApt = maxApt;
    }

    public int getFocalLength() {
        return focalLength;
    }

    public void setFocalLength(int focalLength) {
        this.focalLength = focalLength;
    }


    @Override
    public String toString() {
        return "" + make +"  "
                + focalLength + "mm   F"
                + maxApt ;
    }
}
